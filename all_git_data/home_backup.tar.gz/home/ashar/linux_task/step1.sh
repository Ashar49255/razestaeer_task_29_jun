#!/bin/bash

#FILENAME="best.txt"
#DATA="ya file ma data ashar ka hai "

#echo "$DATA" > "$FILENAME"

#echo "file 'FILENSME' create ho gie aa "
#-------------------------------------------------------------

#mkdir devops
#touch devops/test.txt

#echo "create dir and file"
#---------------------------------------------

#mv best.txt file1.txt myfile.txt testfile devops/
#echo "mv successfull"
#--------------------------------------------

sudo chown ashar:root test.txt
ls -l test.txt
echo "work is successfull"
