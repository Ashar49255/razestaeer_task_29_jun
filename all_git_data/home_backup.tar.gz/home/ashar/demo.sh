#!/bin/bash

if [ "$1" = "like" ]
then
 echo "hello: $1 this video "
else
 echo "oky please subscribe this chennel"
fi
