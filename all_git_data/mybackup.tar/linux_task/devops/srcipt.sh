#!/bin/bash

rm -f myfile.txt testfile test.txt

mkdir -p fastapi/test

echo "confirm task"
